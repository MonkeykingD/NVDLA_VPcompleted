# Changelog

## [v1.2.0]
## Added
 * GreenRouter: DMI Invalidate support for dynamic memory map
 * Version file
## Fixed
 * FindSystemC with CMake < 2.8.11

## [v1.1.0]
 * MinGW support
 * SystemC 2.3.1 support

## 2014-11-10  KONRAD Frederic  <fred.konrad@greensocs.com>
 * Add serial socket to GreenLib.

[v1.2.0]: http://git.greensocs.com/greenlib/greenlib/compare/v1.1.0...v1.2.0
[v1.1.0]: http://git.greensocs.com/greenlib/greenlib/commits/v1.1.0
