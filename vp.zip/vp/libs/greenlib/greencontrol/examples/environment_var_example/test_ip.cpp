//   GreenControl framework
//
// LICENSETEXT
//
//   Copyright (C) 2007 : GreenSocs Ltd
// 	 http://www.greensocs.com/ , email: info@greensocs.com
//
//   Developed by :
//   
//   Marcus Bartholomeu <bartho@greensocs.com>
//     GreenSocs
//     http://www.greensocs.com
//
//
// The contents of this file are subject to the licensing terms specified
// in the file LICENSE. Please consult this file for restrictions and
// limitations that may apply.
// 
// ENDLICENSETEXT

#include "test_ip.h"

void Test_IP::main_action()
{
  std::cout << "Get parameter param1: " << param1 <<std::endl;
  std::cout << "Get parameter param2: " << param2 <<std::endl;
  std::cout << "Get parameter param3: " << param3 <<std::endl;
  std::cout << "Get parameter param4: " << param4 <<std::endl;
  std::cout << "Get parameter param5: " << param5 <<std::endl;
  std::cout << "Get parameter param6: " << param6 <<std::endl;
}
