GreenControl examples

This folder contains examples for the GreenControl 
framework and its sub projects.

- Examples without one of the following prefixes are
  GreenConfig examples

- Examples with the prefix gav_ are GreenAV examples

- Examples with the prefix gcnf_ are GreenAV examples


- The files expected_output.txt in the example folders contain
  reference outputs compiled with SystemC 2.2
